"""
Water Treatment Plant Simulator: Main Entry Point

This is the main script to launch the simulator.
It handles configuration loading, dependency version checking,
and starting the Modbus server and simulation loop.
"""
import logging
import yaml
import argparse
import os

# Check for pyModbusTCP before doing anything else
try:
    import pyModbusTCP
except ImportError:
    print("\n--- ERROR: pyModbusTCP is not installed! ---")
    print("This simulator has been updated to use the pyModbusTCP library.")
    print("Please install the required libraries by running:")
    print("pip install pyModbusTCP pyyaml\n")
    exit(1)

# Now, import the simulator class
from plc.modbus_server import WaterPlantSimulator

# --- Setup Logging ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
log = logging.getLogger()

def main():
    """Main function to run the simulator."""
    print("--- Launching Water Treatment Plant Simulator ---")
    parser = argparse.ArgumentParser(description="Water Treatment Plant SCADA Simulator")
    parser.add_argument(
        "--config",
        default="configs/water_plant_config.yaml",
        help="Path to the master YAML configuration file."
    )
    args = parser.parse_args()
    
    if not os.path.exists(args.config):
        log.error(f"FATAL: Configuration file not found at '{args.config}'")
        log.error("Please ensure the config file exists and you are running from the project root.")
        return
        
    log.info(f"Using configuration file: {args.config}")

    try:
        with open(args.config, 'r') as f:
            config = yaml.safe_load(f)
        log.info("Configuration loaded successfully.")
    except yaml.YAMLError as e:
        log.error(f"FATAL: Error parsing YAML configuration file: {e}")
        return

    simulator = WaterPlantSimulator(config)
    try:
        # The new run() method is synchronous and handles the full lifecycle.
        simulator.run()
    except KeyboardInterrupt:
        log.info("Simulator interrupted by user.")
    except Exception as e:
        log.critical(f"A critical error occurred during simulation: {e}", exc_info=True)
    finally:
        # The run() method now handles its own cleanup, but we can log a final message.
        log.info("Simulator shutdown complete.")

if __name__ == "__main__":
    main()

