"""
Water Treatment Plant Simulator: Main Modbus Server Class (using pyModbusTCP)

This script defines the WaterPlantSimulator class which initializes and runs
the Modbus TCP server, orchestrates the simulation loops (PLC logic, attacks),
and handles the detailed data logging.
This version has been re-written to use the simpler pyModbusTCP library to
avoid the complexities and versioning issues of pymodbus.
"""
import logging
import datetime
import csv
import os
import time

from pyModbusTCP.server import ModbusServer, DataBank

from plc.plc_logic import PLCLogic
from plc.attack_simulator import AttackSimulator

log = logging.getLogger(__name__)

class WaterPlantSimulator:
    def __init__(self, config):
        self.config = config
        self.register_map = config['register_map']
        self.is_running = True
        self.simulation_data = []

        # 1. PLCLogic still holds and manages the plant's state internally.
        self.plc = PLCLogic(self.register_map, config['process_parameters'])

        # 2. The attacker manipulates the PLC's state directly.
        self.attacker = AttackSimulator(self.plc, self.register_map, config.get('attack_scenarios', []))

        # 3. Create a DataBank instance. This will store the Modbus data.
        self.data_bank = DataBank()

        # 4. Setup the pyModbusTCP Server and pass our DataBank instance to it.
        server_config = self.config['plc']
        self.server = ModbusServer(
            host=server_config['ip_address'],
            port=server_config['port'],
            no_block=True,  # Allows the server to run in a non-blocking thread
            data_bank=self.data_bank # Use our own DataBank instance
        )

    def _log_state(self, log_entry, state_suffix):
        """Helper function to log the current value of all registers with a suffix."""
        for name in self.register_map:
            value = self.plc.state.get(name, 0)
            log_entry[f"{name}{state_suffix}"] = value

    def run(self):
        """Starts the server and runs the main simulation loop."""
        try:
            log.info(f"Starting Modbus TCP server on {self.config['plc']['ip_address']}:{self.config['plc']['port']}...")
            self.server.start()
            log.info("Server is running.")

            start_time = datetime.datetime.now()
            total_sim_duration_delta = datetime.timedelta(hours=self.config['simulation']['duration_hours'])
            time_step_seconds = self.config['simulation']['time_step_seconds']

            while self.is_running:
                current_sim_time_delta = datetime.datetime.now() - start_time
                if current_sim_time_delta > total_sim_duration_delta:
                    self.is_running = False
                    break

                # --- 1. Logging and Logic Updates ---
                log_entry = {
                    "timestamp": datetime.datetime.now().isoformat(),
                    "sim_time": str(current_sim_time_delta)
                }
                
                self._log_state(log_entry, "_before_update")
                self.plc.update(current_sim_time_delta)
                self._log_state(log_entry, "_after_logic")
                self.attacker.update(current_sim_time_delta)
                self._log_state(log_entry, "_after_attack")

                log_entry["active_attack"] = self.attacker.active_attack
                self.simulation_data.append(log_entry)

                # --- 2. Manually Update Modbus Server DataBank ---
                # FIX: Check the register type from the config and update the correct DataBank table.
                for name, details in self.register_map.items():
                    address = details['address'] - 1
                    value = self.plc.state.get(name, 0)
                    reg_type = details.get('type', 'hr').lower() # Default to holding register if not specified

                    if reg_type == 'hr': # Holding Register
                        self.data_bank.set_holding_registers(address, [int(value)])
                    elif reg_type == 'ir': # Input Register
                        self.data_bank.set_input_registers(address, [int(value)])
                    elif reg_type == 'co': # Coil
                        self.data_bank.set_coils(address, [bool(value)])
                    elif reg_type == 'di': # Discrete Input
                        self.data_bank.set_discrete_inputs(address, [bool(value)])


                time.sleep(time_step_seconds)

        finally:
            log.info("Simulation finished. Shutting down...")
            self.server.stop()
            log.info("Server stopped.")
            self.save_data_to_csv()

    def save_data_to_csv(self):
        """Writes the collected simulation data to a CSV file."""
        csv_path = self.config['simulation']['output_csv_path']
        
        # Create directory if it doesn't exist
        if os.path.dirname(csv_path):
             os.makedirs(os.path.dirname(csv_path), exist_ok=True)

        if not self.simulation_data:
            log.warning("No data to save.")
            return

        header = self.simulation_data[0].keys()
        try:
            with open(csv_path, 'w', newline='') as output_file:
                dict_writer = csv.DictWriter(output_file, fieldnames=header)
                dict_writer.writeheader()
                dict_writer.writerows(self.simulation_data)
            log.info(f"Data successfully saved to {csv_path}")
        except IOError as e:
            log.error(f"Could not write to file {csv_path}: {e}")

