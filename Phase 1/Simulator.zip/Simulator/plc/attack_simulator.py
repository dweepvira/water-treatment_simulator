"""
Water Treatment Plant Simulator: Cyber Attack Simulation

This module injects malicious data into the Modbus datastore
based on the scenarios defined in the configuration file.
"""
import datetime
import logging

log = logging.getLogger(__name__)

class AttackSimulator:
    """
    Executes cyber attack scenarios by directly manipulating the PLC's state dictionary.
    """
    def __init__(self, plc_object, register_map, scenarios):
        self.plc = plc_object
        self.r_map = register_map
        self.scenarios = self._parse_scenarios(scenarios)
        self.active_attack = "None"

    def _parse_scenarios(self, scenarios):
        """Converts time strings from config into timedelta objects for comparison."""
        if not scenarios:
            return []
        parsed_scenarios = []
        for s in scenarios:
            try:
                # Convert HH:MM:SS string to a timedelta object
                h, m, sec = map(int, s['start_time'].split(':'))
                s['start_delta'] = datetime.timedelta(hours=h, minutes=m, seconds=sec)
                h, m, sec = map(int, s['end_time'].split(':'))
                s['end_delta'] = datetime.timedelta(hours=h, minutes=m, seconds=sec)
                parsed_scenarios.append(s)
            except (ValueError, KeyError) as e:
                log.error(f"Invalid time format in attack scenario '{s.get('name', 'Unnamed')}': {e}. Skipping this scenario.")
        return parsed_scenarios

    def update(self, current_sim_time_delta):
        """
        Checks if any attacks should be active at the current simulation time
        and executes them.
        """
        self.active_attack = "None"

        for scenario in self.scenarios:
            if scenario['start_delta'] <= current_sim_time_delta <= scenario['end_delta']:
                self.active_attack = scenario['name']
                self._execute_attack(scenario)
                break

    def _execute_attack(self, scenario):
        """Performs the malicious action on the PLC's internal state."""
        attack_type = scenario['attack_type']
        target_reg_name = scenario['target_register']
        params = scenario['parameters']

        # Ensure the target register exists in the PLC state to prevent errors
        if target_reg_name not in self.plc.state:
            log.warning(f"Attack scenario '{scenario['name']}' references an unknown register '{target_reg_name}'. Skipping.")
            return

        if attack_type == "set_sensor_value" or attack_type == "set_actuator_value":
            value_to_set = int(params['value'])
            self.plc.state[target_reg_name] = value_to_set

        elif attack_type == "offset_sensor":
            original_value = self.plc.state.get(target_reg_name, 0)
            offset = int(params['offset'])
            new_value = max(0, original_value + offset) # Prevent negative values
            self.plc.state[target_reg_name] = new_value
