"""
Water Treatment Plant Simulator: PLC Logic and Process Simulation

This module simulates the physical water treatment process and the
control logic that a real PLC would execute.
"""
import random

class PLCLogic:
    """
    Simulates the water treatment process and control logic.
    It now manages the plant's state internally in a dictionary.
    """
    def __init__(self, register_map, params):
        self.r_map = register_map
        self.params = params
        self.stuck_sensors = {}
        
        
        # Initialize all registers to 0.
        self.state = {name: 0 for name in self.r_map.keys()}

    def update(self, current_time):
        """Executes one step of the simulation logic."""

        # --- 1. SIMULATE EXTERNAL CONDITIONS (RAW WATER) ---
        base_turbidity = self.params['raw_water_turbidity_normal'] + random.uniform(-5, 5)
        if random.random() < 0.01: # Chance of a random spike
            base_turbidity += random.uniform(50, 150)
        self.state["raw_water_turbidity"] = int(base_turbidity)

        # --- 2. FAULTY SENSOR SIMULATION ---
        for name in self.r_map:
            if 'turbidity' in name and random.random() < self.params['faulty_reading_chance']:
                if name not in self.stuck_sensors:
                    # FIX: Read from internal state
                    current_value = self.state.get(name, 0)
                    stuck_duration = random.randint(10, 50)
                    self.stuck_sensors[name] = {"value": current_value, "steps_left": stuck_duration}

        for name in list(self.stuck_sensors.keys()):
            self.stuck_sensors[name]["steps_left"] -= 1
            if self.stuck_sensors[name]["steps_left"] <= 0:
                del self.stuck_sensors[name]
            else:
                self.state[name] = self.stuck_sensors[name]["value"]

        # --- 3. READ SENSOR VALUES FROM INTERNAL STATE ---
        raw_turbidity = self.state["raw_water_turbidity"]

        # --- 4. EXECUTE CONTROL LOGIC ---
        if raw_turbidity > self.params['raw_water_turbidity_high_threshold']:
            # FIX: Write control decision to internal state
            self.state["coagulant_pump_speed"] = self.params['coagulant_pump_speed_high']
        else:
            self.state["coagulant_pump_speed"] = self.params['coagulant_pump_speed_normal']

        # --- 5. SIMULATE THE PHYSICAL PROCESS ---
        
        coag_pump_speed = self.state["coagulant_pump_speed"]

        coag_pump_high = self.params['coagulant_pump_speed_high']
        coag_effectiveness_ratio = coag_pump_speed / coag_pump_high if coag_pump_high > 0 else 0
        coag_effectiveness = coag_effectiveness_ratio * random.uniform(0.85, 0.95)

        turbidity_after_sed = raw_turbidity * (1 - coag_effectiveness)
        self.state["sedimentation_turbidity"] = int(turbidity_after_sed)

        final_turbidity = turbidity_after_sed * random.uniform(0.05, 0.15)
        self.state["filter_outlet_turbidity"] = int(final_turbidity)
